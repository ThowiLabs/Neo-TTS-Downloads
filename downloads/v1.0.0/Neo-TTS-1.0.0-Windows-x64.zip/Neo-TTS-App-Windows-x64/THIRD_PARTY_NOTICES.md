# Neo-TTS — componentes externos y derechos de distribución

Revisión técnica del 18 de octubre de 2026; no sustituye una opinión legal.
El motor de pronunciación Neo G2P C++ es código propio. **Eso no convierte
toda la aplicación ni sus dependencias en software de titularidad exclusiva.**

## Componentes distribuidos

| Componente | Función | Base de licencia | Acción |
| --- | --- | --- | --- |
| Qt 6 Widgets, Multimedia, Svg, Core, plugins | Interfaz Windows/Linux, audio | Qt LGPLv3 u opción comercial (depende del módulo) | Cumplir condiciones LGPL3, avisos, código fuente correspondiente y derechos de reemplazo/re-enlace de bibliotecas dinámicas. Revisar módulos y versión por plataforma |
| ONNX Runtime 1.22 | Inferencia VITS/Piper | MIT | Conservar aviso de copyright/licencia |
| CMUdict | Diccionario inglés | BSD-2-Clause | Incluir LICENSE-CMUdict-BSD2; **pendiente reemplazo propio** |
| OpenSSL | Criptografía de firmas | Apache-2.0 | Conservar aviso/licencia y avisos de terceros que correspondan |
| json-c | Lectura JSON | MIT | Conservar aviso/licencia |
| Zstandard / zstd-jni | Descompresión de modelo | BSD-3/MIT y condiciones correspondientes | Verificar variante exacta y avisos del paquete |
| Lucide | Iconos | ISC | Conservar licencia |
| Qt Multimedia / FFmpeg si incluido | Reproducción de audio | FFmpeg normalmente LGPL2.1+; puede variar según opciones | Comprobar build flags, codec, términos y avisos. Añadir licencia/código fuente correspondiente al distribuir |
| AndroidX/Compose, Kotlin, NDK runtime | UI Android | Componentes de terceros, p.ej. Apache-2.0 | Revisar dependencias transitivas de AAR/APK antes de publicar |

No se incluye espeak-ng ni piper-phonemize en la versión de prueba G2P.
El workflow heredado de GitHub Actions todavía **instala eSpeak en el runner**
y usa un alias --check-espeak que no llama a eSpeak: permiso workflows
de la integración GitHub insuficiente para editar el YAML desde esta conexión.

## Requisitos pendientes antes de etiquetar producto comercial

- Auditar inventario real de ejecutables, plugins y bibliotecas empaquetadas,
  incluida la cadena Qt Multimedia/FFmpeg y el backend escogido.
- Adjuntar licencias/avisos apropiados a cada distribución. Revisar la opción
  LGPL/comercial Qt, permiso de modificación y sustitución de las DLL/SO.
- Documentar disponibilidad del código fuente de los componentes LGPL y
  cualquier modificación de esos componentes. Conservar avisos exactos.
- No redistribuir modelos de voz .neo ajenos sin una licencia explícita para ellos.
  La app permite que el usuario importe modelos; no se incluyen en el paquete.
- Revisar términos y requisitos de distribución en Google Play al publicar:
  el APK actual es un preview de depuración sin revisión de tienda ni QA física.

Referencias oficiales:
- https://www.qt.io/development/open-source-lgpl-obligations
- https://www.qt.io/faq/qt-open-source-licensing
- https://doc.qt.io/qt-6.8/licensing.html
- https://github.com/microsoft/onnxruntime/blob/main/LICENSE

Estado: **auditoría preliminar, distribución privativa no certificada**.
